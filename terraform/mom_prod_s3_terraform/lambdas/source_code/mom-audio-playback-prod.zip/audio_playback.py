""" [Audio Serve]

This module allows the user to listen the audio files 
stored on S3 from UI.

This script requires packages mentioned in "requirements.txt "to 
be installed within the Python environment you are running this script in

This file can also be imported as a module and contains the following
functions:

    * lambda_hand              - returns base64 encoded string of audio-file.
    * detokenize               - returns the detokenized data using Protegrity 
                                 detokenize-url
    * get_audio_object_from_s3 - returns the content of audio-file in form of bytes
"""

import base64
import json
import logging
import os

import boto3
import config_client
import requests
from botocore import exceptions

logging.basicConfig(
    format="%(levelname)s - %(asctime)s - %(name)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    level=logging.INFO,
)
logger = logging.getLogger(__file__)
logger.setLevel(logging.INFO)


def get_audio_object_from_s3(bucket_name: str, object_prefix: str) -> bytes:

    """
    This function retruns the content of audio-file in form of bytes

    Parameters
    ----------
        :param bucket_name (str): Name of the S3 Bucket.
        :param object_prefix(str): Prefix of audio file which contains
                                   the requested file

    Returns
    -------
        :file_content (bytes): Audio file in form of bytes
    """
    try:
        s3_client = boto3.client("s3")
        file_content = s3_client.get_object(Bucket=bucket_name, Key=object_prefix)[
            "Body"
        ].read()
        logger.info("Successfly retrieved the wav file content from S3")
        return file_content

    except exceptions.DataNotFoundError as error:
        err = f"Specified key {object_prefix} does not exist"
        logger.error(err)
        raise RuntimeError(error)

    except exceptions.ConnectTimeoutError as error:
        logger.error("Connection got timed out try increasing the timeout value")
        raise RuntimeError(error)


def detokenize(file_content: bytes) -> bytes:

    """
    This function detokenizes the binary file using Protegrity

    Parameters
    ----------
        :param file_content(bytes): Bytes to be detokenized

    Returns
    -------
        :response (bytes): Detokenized Bytes
    """
    config = config_client.get_soa_configs()
    headers = {"Accept": "text/plain", "Content-Type": "text/plain"}

    response = requests.request(
        "POST",
        config.get("DETOKENIZE_URL"),
        data=file_content,
        headers=headers,
        auth=(config.get("PROTEGRITY_USERNAME"), config.get("PROTEGRITY_PASSWORD")),
        verify="root_chain.pem",
    )
    response.raise_for_status()
    if response.status_code == 200:
        return response.content
    else:
        error = f"Process failed at tokenizing audio file {response.text}"
        logger.error(error)
        raise RuntimeError(error)


def audio_playback_handler(event, context):

    """
    Entrypoint function for audio serve module which handles tokenized/encrypted
    audio file content from S3 and detokenizing and then encoding the bytes into
    base64 string

    Parameters
    ----------
        :param event (dict): Lambda event dictionary.
        :param context(LambdaContext()): Lambda Context

    Returns
    -------
        :audio_content (dict): Encoded base64 string with relevant headers
         in form of dictionary
    """

    s3_url = event["queryStringParameters"]["file"]
    bucket_name, object_prefix = s3_url.replace("s3://", "").split("/", 1)
    file_content = get_audio_object_from_s3(
        bucket_name=bucket_name, object_prefix=object_prefix
    )
    response = detokenize(file_content=file_content)
    logger.info("Detokenization of audio-file has been completed")
    encoded_audio_string = base64.b64encode(response).decode("utf-8")
    logger.info("Encoding of bytes into base64 string has been completed")
    return {
        "headers": {"Content-Type": "audio/x-wav"},
        "statusCode": 200,
        "body": encoded_audio_string,
        "isBase64Encoded": True,
    }
