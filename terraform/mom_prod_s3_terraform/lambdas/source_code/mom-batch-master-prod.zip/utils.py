from time import time
import logging

logger = logging.getLogger(__file__)
logger.setLevel(logging.INFO)


def timeit_logger(func):
    """Decorator for logging time taken for a function to be executed"""

    def wrap_func(*args, **kwargs):
        t1 = time()
        result = func(*args, **kwargs)
        logger.info(
            f"Function {func.__name__} executed in {(time()-t1):0.2f}s"
        )
        return result

    return wrap_func


def get_call_back_id(ner):
    """Get call back id from NER response"""
    l = [e["entity"] for e in ner if e["label"] == "CALLBACK_ID"]
    logger.debug(f"Callback id is {l}")
    if l:
        return l[0]
