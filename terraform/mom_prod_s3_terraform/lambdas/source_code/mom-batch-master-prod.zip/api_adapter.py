import json
import logging

import requests
from requests.models import Response

from config import Settings
from utils import timeit_logger

logger = logging.getLogger(__file__)
logger.setLevel(logging.INFO)


def get_request(endpoint: str, token: bytes) -> Response:
    """Helper function for making a Get request along with access token"""
    response: Response = requests.get(
        endpoint, headers={"Authorization": f"Bearer {token}"}
    )
    logger.info(
        f"Request completed for GET {endpoint} in {response.elapsed.total_seconds():0.2f}s"
    )
    return response


def post_request(
    endpoint: str,
    data: dict,
    token: bytes = None,
    params: dict = None,
    ssl_verify: bool = True,
) -> Response:
    """Helper function for making a POST request along with access token"""
    headers = {
        "Content-Type": "application/json",
    }
    if token:
        headers["Authorization"] = f"Bearer {token}"
    response: Response = requests.post(
        endpoint,
        data=json.dumps(data),
        params=params,
        headers=headers,
        verify=ssl_verify,
    )
    logger.info(
        f"Request completed for POST {endpoint} in {response.elapsed.total_seconds():0.2f}s"
    )
    return response


def patch_request(endpoint: str, data: json, token: bytes = None) -> Response:
    """Helper function for making a PATCH request along with access token"""
    headers = {
        "Content-Type": "application/json",
    }
    if token:
        headers["Authorization"] = f"Bearer {token}"
    return requests.patch(endpoint, data=data, headers=headers)


@timeit_logger
def add_voicemail_details_db(
    data: dict,
    settings: Settings,
    vmb_name: str,
    vm_id: int = None,
    ssl_verify: bool = True,
) -> dict:
    """Helper function for adding voicemail data to DB.
    :params
           data: Data which has to be inserted in the DB.
           settings: Configuration object for getting environment variables.
           vm_id: if passed, function will make an update on the record else it wil add a new record.
    :raises
        RuntimeError if API-GW API doesn't respond with an ok status or if there is an connection timeout
    """
    try:
        res = post_request(
            f"{settings.API_GW_BASE}/auth/login",
            {
                "username": settings.LDAP_USERNAME,
                "password": settings.LDAP_PASSWORD,
            },
            ssl_verify=ssl_verify,
        )
        if res.ok:
            token = res.json()["access_token"]
            if vm_id:
                patch_request(
                    f"{settings.API_GW_BASE}/add-voicemail?voicemail_box_name/{vmb_name}",
                    data,
                    token=token,
                )
            else:
                res = post_request(
                    f"{settings.API_GW_BASE}/add-voicemail",
                    data,
                    token=token,
                    params={"voicemail_box_name": vmb_name},
                    ssl_verify=ssl_verify,
                )
                logger.debug(f"Request data is {data}")
                if not res.ok:
                    raise RuntimeError(
                        f"Process failed while adding transcript to DB with error {res.text}"
                    )
            return res
        err = f"Process failed at login request with error {res.text}"
        raise RuntimeError(err)
    except Exception as e:
        logger.error(str(e))
        raise RuntimeError(str(e))


@timeit_logger
def get_ner(transcript: str, base_uri: str, ssl_verify: bool) -> dict:
    """Helper function returning reason for call and NER predictions on a transcript output using NLP APIs.

    :param
           transcript: Transcript on which prediction needs to be done.
           base_uri: Base URL of NLP endpoints.

    :raises
        RuntimeError if NLP API doesn't respond with an ok status or if there is an connection timeout.
    """
    data = {"transcript": transcript}
    try:
        ner = post_request(f"{base_uri}/ner", data, ssl_verify=ssl_verify)

        if ner.ok:
            logger.debug(f"NER is {ner.json()}")

            return ner.json()
        else:
            err = f"Process failed at NER predictions step with error and {ner.text}"
            logger.error(err)
            raise RuntimeError(err)
    except Exception as e:
        err = f"Process failed at NER predictions with error {str(e)}"
        logger.error(err)
        raise RuntimeError(err)


@timeit_logger
def get_reason_for_call(
    transcript: str, base_uri: str, ssl_verify: bool
) -> dict:
    """Helper function returning reason for call and NER predictions on a transcript output using NLP APIs.

    :param
           transcript: Transcript on which prediction needs to be done.
           base_uri: Base URL of NLP endpoints.

    :raises
        RuntimeError if NLP API doesn't respond with an ok status or if there is an connection timeout.
    """
    data = {"transcript": transcript}
    try:
        reason = post_request(
            f"{base_uri}/classifier_model", data, ssl_verify=ssl_verify
        )

        if reason.ok:
            logger.debug(f"Reason is {reason.json()}")

            return reason.json()
        else:
            err = f"Process failed at reason for call predictions step with error {reason.text}"
            logger.error(err)
            raise RuntimeError(err)
    except Exception as e:
        err = f"Process failed at reason for call predictions with error {str(e)}"
        logger.error(err)
        raise RuntimeError(err)


@timeit_logger
def normalize_text(transcript: str, base_uri: str, ssl_verify: bool) -> str:
    try:
        logger.info("Started normalization process")
        res = post_request(
            f"{base_uri}/text_normalization",
            {"transcript": transcript},
            ssl_verify=ssl_verify,
        )

        if res.ok:
            logger.debug(f"Normalized text {res.json()}")
            return res.json()["predictions"][0]["text_normalize"]
        else:
            err = f"Process failed at text normalization {res.text} "
            logger.error(err)
            raise RuntimeError(err)
    except Exception as e:
        err = f"Process failed at text normalization with error {str(e)}"
        logger.error(err)
        raise RuntimeError(err)
