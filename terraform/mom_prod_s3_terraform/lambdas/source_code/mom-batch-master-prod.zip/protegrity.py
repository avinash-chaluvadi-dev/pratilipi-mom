import logging
from pathlib import Path

import requests

from config import Settings
from s3_utils import Bucket
from utils import timeit_logger

logger = logging.getLogger(__file__)
logger.setLevel(logging.INFO)


@timeit_logger
def binary_tokenize(byte_data: bytes, settings: Settings) -> bytes:
    """
    Tokenize a binary file using Protegrity.

    :Params
        byte_data: bytes to be tokenized
        settings: Config settings object

    :Returns Tokenized bytes

    """
    try:
        response = requests.request(
            "POST",
            settings.TOKENIZE_URL,
            headers={"Content-Type": "application/octet-stream"},
            data=byte_data,
            auth=(settings.PROTEGRITY_USERNAME, settings.PROTEGRITY_PASSWORD),
            verify=f"{Path(__file__).resolve().parent}/root_chain.pem",
        )
        if response.status_code == 200:
            return response._content
        else:
            err = f"Process failed at tokenizing audio file {response.text}"
            logger.error(err)
            raise RuntimeError(err)
    except Exception as e:
        err = (
            f"Process failed while adding transcript to DB with error {str(e)}"
        )
        logger.error(err)
        raise RuntimeError(err)


@timeit_logger
def encrypt_and_upload_to_s3(
    decoded_file: bytes,
    settings: Settings,
    vmb_name: str,
    file_name: str,
    s3: Bucket,
):
    """Tokenizes a binary file and uploads to S3"""
    logger.info("Started Tokenizing process")
    tokenized_data = binary_tokenize(decoded_file, settings)

    # Upload tokenize file
    s3.upload(
        f"{vmb_name}/{file_name}",
        tokenized_data,
    )
    logger.info("Uploaded encrypted file")
