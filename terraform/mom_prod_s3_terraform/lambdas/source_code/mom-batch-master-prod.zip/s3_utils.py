import boto3

from utils import timeit_logger


class Bucket:
    """For initailzing Bucket and functions to"""

    def __init__(self, settings):
        print(self.__class__)
        self.settings = settings
        self.resource = boto3.resource("s3")

    @timeit_logger
    def upload(self, file_name: str, data: bytes):
        """A function for putting objects in to S3 bucket.
        This function should used when trying to upload a binary file which is passed a bytes
        The file will be uploaded in the S3 bucket folder specified via config.

        :params file_name :  Name of the file with which file has to be uploaded
                data : Content which has to be uploaded in S3

        """
        s3_wav_path = self.settings.S3_BUCKET_FOLDER + file_name
        self.resource.Object(self.settings.S3_BUCKET, s3_wav_path).put(
            Body=data,
        )
