import dataclasses


class EnforcedDataclassMixin:
    def __post_init__(self):
        for field in dataclasses.fields(self):
            value = getattr(self, field.name)
            if field.type == list and field.name != "SKIP_WORKFLOW":
                value = value.split(",")
            setattr(self, field.name, field.type(value))
            if field.type == bool:
                value = int(value)
            setattr(self, field.name, field.type(value))


@dataclasses.dataclass
class Settings(EnforcedDataclassMixin):
    S3_BUCKET: str
    S3_BUCKET_FOLDER: str
    TRANSCRIBE_JOB_NAME: str
    CLIENT_ID: str
    CLIENT_SECRET: str
    TENANT_ID: str
    USER_ID: str
    DESTINATION: str
    EXTENSION: str
    NLP_API_BASE: str
    API_GW_BASE: str
    AUTHORITY: str
    SCOPES: list
    GRAPH_API_BASE: str
    READ_EMAIL_PAGE_SIZE: int
    LDAP_USERNAME: str
    LDAP_PASSWORD: str
    TOKENIZE_URL: str
    PROTEGRITY_USERNAME: str
    PROTEGRITY_PASSWORD: str
    SSL_VERIFY: bool
    SKIP_WORKFLOW: list
    SKIP_VMB_NAME: str

    @classmethod
    def from_dict(cls, env):
        return cls(
            **{
                k: v
                for k, v in env.items()
                if k in set([f.name for f in dataclasses.fields(cls)])
            }
        )
