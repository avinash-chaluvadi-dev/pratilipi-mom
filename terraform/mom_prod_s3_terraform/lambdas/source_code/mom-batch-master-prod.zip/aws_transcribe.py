import logging
import time
from typing import Union

import boto3
import requests

from utils import timeit_logger

logger = logging.getLogger(__file__)
logger.setLevel(logging.INFO)


class Transcribe:
    """For intializing the Transcribe JOb"""

    def __init__(self, settings, s3_wav_file):
        self.settings = settings
        self.s3_wav_file = s3_wav_file
        self.client = boto3.client("transcribe")

    def is_ready(self):
        """Check if a Transcribe job is running, if a job is completed status it will delete it.

        :raises RuntimeError if a job is already in progress
        """
        try:
            self.job = self.client.get_transcription_job(
                TranscriptionJobName=self.settings.TRANSCRIBE_JOB_NAME
            )
            if (
                self.job["TranscriptionJob"]["TranscriptionJobStatus"]
                == "IN_PROGRESS"
            ):
                err = f"Job already in progress, So skipping the process"
                logger.error(err)
                raise RuntimeError(err)
            self.cleanup()
        except Exception:
            logger.info("No job found. Proceeding with batch processing")

    def cleanup(self):
        """Deletes transcribe job if it is in completed or failed status"""
        if self.job and self.job["TranscriptionJob"][
            "TranscriptionJobStatus"
        ] in ["COMPLETED", "FAILED"]:
            self.client.delete_transcription_job(
                TranscriptionJobName=self.job["TranscriptionJob"][
                    "TranscriptionJobName"
                ]
            )
            logger.info("Found job in completed status, deleting it")
            self.job = None

    def handle_transcribe_failure(self):
        """Deletes transcribe job if it is in completed or failed status.

        :raises RuntimeError which should caught at main level and returned a proper response to client
        """
        # TODO: Update status in DB here
        self.cleanup()
        err = f"Process failed at transcript generation step for wav file {self.s3_wav_file}"
        logger.error(err)
        raise RuntimeError(err)

    @timeit_logger
    def transcribe_file(self, file_uri) -> Union[str, None]:
        """
        Return transcript of an audio file.
        The audio file must already be present in S3 bucket specified in the environment variables,
        if the file is not present the function execution will be skipped.

        :raises RuntimeError which should caught at main level and returned a proper response to client
        """
        if not self.s3_wav_file:
            logger.error("No file specified for transcribing")
            raise RuntimeError("No file specified for transcribing")

        self.client.start_transcription_job(
            TranscriptionJobName=self.settings.TRANSCRIBE_JOB_NAME,
            Media={"MediaFileUri": file_uri},
            MediaFormat="wav",
            LanguageCode="en-US",
        )
        self.job = None
        try:
            max_tries = 200
            while max_tries > 0:
                max_tries -= 1
                self.job = self.client.get_transcription_job(
                    TranscriptionJobName=self.settings.TRANSCRIBE_JOB_NAME
                )
                job_status = self.job["TranscriptionJob"][
                    "TranscriptionJobStatus"
                ]

                if job_status in ["COMPLETED", "FAILED"]:
                    logger.info(
                        f"Job {self.settings.TRANSCRIBE_JOB_NAME} is {job_status}."
                    )
                    if job_status == "COMPLETED":
                        transcript_simple = requests.get(
                            self.job["TranscriptionJob"]["Transcript"][
                                "TranscriptFileUri"
                            ]
                        ).json()
                        logger.debug(
                            f"Transcript for job {transcript_simple['jobName']}:"
                        )
                        aws_transcript = transcript_simple["results"][
                            "transcripts"
                        ][0]["transcript"]
                        logger.debug(f"aws transcript is {aws_transcript}")
                        return aws_transcript
                    else:
                        logger.error("Transcribe job failed")
                        self.handle_transcribe_failure()

                else:
                    logger.info(
                        f"Waiting for {self.settings.TRANSCRIBE_JOB_NAME}. Current status is {job_status}."
                    )
                time.sleep(2)
        except Exception as e:
            logger.error(f"Exception occurred {str(e)}")
            self.handle_transcribe_failure()
        finally:
            self.cleanup()
