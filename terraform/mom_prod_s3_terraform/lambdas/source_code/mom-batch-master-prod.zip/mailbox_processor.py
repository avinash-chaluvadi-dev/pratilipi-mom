import logging
from typing import Iterator

import msal

from api_adapter import get_request, post_request
from config import Settings
from utils import timeit_logger


logger = logging.getLogger()
logger.setLevel(logging.INFO)


class AzureMailBox:
    """For initailzing mail client and functions to read & archive"""

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.access_token = None

    def get_client_app(self) -> msal.ConfidentialClientApplication:
        """Returns a MSAL confidential client application which can be used for performing API calls to MS Graph"""
        return msal.ConfidentialClientApplication(
            client_id=self.settings.CLIENT_ID,
            client_credential=self.settings.CLIENT_SECRET,
            authority=f"{self.settings.AUTHORITY}/{self.settings.TENANT_ID}",
        )

    def generate_access_token(self) -> None:
        """Generates a new access token for graph API"""
        app = self.get_client_app()
        res = app.acquire_token_silent(self.settings.SCOPES, account=None)
        if not res:
            logger.info(
                "No suitable token exists in cache. Let's get a new one from Azure Active Directory."
            )
            res = app.acquire_token_for_client(scopes=self.settings.SCOPES)

        self.access_token = res["access_token"]

    def get_access_token(self) -> bytes:
        """Returns an access token for graph API if already present in session or else creates a new one"""
        if not self.access_token:
            self.generate_access_token()
        return self.access_token

    @timeit_logger
    def get_emails(self) -> list:
        """Return all the emails present in current user's inbox as a list"""
        res = get_request(
            f"{self.settings.GRAPH_API_BASE}/users/{self.settings.USER_ID}/mailFolders/Inbox/messages?$top={self.settings.READ_EMAIL_PAGE_SIZE}&$orderby=receivedDateTime asc",
            self.get_access_token(),
        )

        if res.ok:
            messages = res.json()["value"]
            logger.info("Emails retrieved successfully")
            logger.info(f"Number of emails in inbox are {len(messages)}")
            return messages
        else:
            logger.error(f"Error while fetching emails: {res.text}")

    @timeit_logger
    def download_attachment(self, message: dict) -> Iterator:
        """Downloads attachments from an Email using Graph API if it has specific a specific extension given from config.

        :params
                message     :   Message from which attachments has to be downloaded
        """
        logger.debug(f"Message subject: {message['subject']}")
        logger.debug(f"Message body: {message['body']}")
        attachments = get_request(
            f"{self.settings.GRAPH_API_BASE}/users/{self.settings.USER_ID}/messages/{message['id']}/attachments",
            self.get_access_token(),
        )

        if attachments.ok:
            attachments = attachments.json()
            for attachment in attachments["value"]:
                if self.settings.EXTENSION in attachment["name"]:
                    logger.info("Attachment found")
                    yield attachment
        else:
            logger.error(
                f"Error while fetching Attachments: {attachments.text}"
            )

    @timeit_logger
    def move_email_to_archive(self, message_id: str):
        """Moves an Email to specific folder using Graph API if a Destination is specified in config.

        :params
                message_id  :  ID of the message to be moved.
        """
        if self.settings.DESTINATION:
            res = post_request(
                f"{self.settings.GRAPH_API_BASE}/users/{self.settings.USER_ID}/messages/{message_id}/move",
                {"destinationId": self.settings.DESTINATION},
                self.get_access_token(),
            )
            if not res.ok:
                logger.error(
                    f"Error while moving email with id {message_id} to archive with error: {res.text}"
                )
        else:
            logger.info(
                "No destination location specified, skipping move email step"
            )
