import base64
import logging
from datetime import datetime
from datetime import timedelta
import pytz

from dotenv import dotenv_values

import api_adapter
import aws_transcribe
import config
import config_client
import mailbox_processor
import protegrity
import s3_utils
from utils import get_call_back_id

logging.basicConfig(
    format="%(levelname)s - %(asctime)s - %(name)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    level=logging.INFO,
)
logger = logging.getLogger(__file__)
logger.setLevel(logging.INFO)

env = dotenv_values(".env")


def mailbox_processor_handler(event, context):
    message = "Batch processing complete"
    soa_config = config_client.get_soa_configs()
    env.update(soa_config)
    settings = config.Settings.from_dict(env)
    s3 = s3_utils.Bucket(settings)
    mailbox = mailbox_processor.AzureMailBox(settings)
    messages = mailbox.get_emails()
    decoded_file = vmb_name = file_name = ""
    error_counter = 0

    for msg in messages:
        try:
            timestamp = (
                (
                    datetime.strptime(
                        msg["createdDateTime"], "%Y-%m-%dT%H:%M:%SZ"
                    )
                    + timedelta(milliseconds=1)
                )
                .replace(tzinfo=pytz.utc)
                .astimezone(pytz.timezone("US/Eastern"))
            )
            vmb_name = msg["subject"]
            extn_id = (
                msg["body"]["content"]
                .split("Caller: ")[1]
                .split("\r\n")[0]
                .strip()
            )
            logger.info(f"Timestamp is {timestamp}")

            for attachment in mailbox.download_attachment(msg):

                file = attachment["name"][16:].split(".")
                file_name = f"{file[0]}_{timestamp}.{file[1]}"
                logger.info(f"File name is {file_name}")
                decoded_file = base64.b64decode(attachment["contentBytes"])

                logger.info("Uploading raw file to S3")
                s3.upload(
                    f"{vmb_name}/{file_name}",
                    decoded_file,
                )
                file_uri = f"s3://{settings.S3_BUCKET}/{settings.S3_BUCKET_FOLDER}{vmb_name}/{file_name}"
                logger.debug(f"File uri is {file_uri}")

                transcribe = aws_transcribe.Transcribe(
                    settings, attachment["name"]
                )
                transcribe.is_ready()
                logger.info("Transcribe process started")
                transcript = transcribe.transcribe_file(file_uri)
                nrml_trnscpt = api_adapter.normalize_text(
                    transcript,
                    settings.NLP_API_BASE,
                    ssl_verify=settings.SSL_VERIFY,
                )
                vmb_name_compare = vmb_name
                if settings.SKIP_VMB_NAME and settings.SKIP_VMB_NAME != "":
                    vmb_name_compare = settings.SKIP_VMB_NAME
                workflow = next(
                    (
                        workflow
                        for workflow in settings.SKIP_WORKFLOW
                        if vmb_name_compare == workflow["vm_box"]
                    ),
                    None,
                )

                keys = []
                if workflow:
                    keys = workflow.keys()

                if "reason_for_call" not in keys:
                    reason = api_adapter.get_reason_for_call(
                        nrml_trnscpt,
                        settings.NLP_API_BASE,
                        ssl_verify=settings.SSL_VERIFY,
                    )["predictions"][0]["label"]
                else:
                    reason = workflow["reason_for_call"]

                if "ner" not in keys:
                    ner = api_adapter.get_ner(
                        nrml_trnscpt,
                        settings.NLP_API_BASE,
                        ssl_verify=settings.SSL_VERIFY,
                    )["predictions"][0]["Ner"]
                else:
                    ner = workflow["ner"]

                logger.info("Adding voicemail data to DB")
                api_adapter.add_voicemail_details_db(
                    dict(
                        vm_uuid=datetime.now().strftime(
                            "%Y-%m-%dT%H:%M:%S.%fZ"
                        ),
                        vm_name=attachment["name"],
                        vm_timestamp=str(timestamp),
                        vm_transcript_dtls=transcript,
                        vm_normalized_dtls=nrml_trnscpt,
                        vm_audio_url=file_uri,
                        vm_system_state="Downloaded",
                        vm_review_state="Pending",
                        vm_extension_id=extn_id,
                        vm_ner={"entities": ner},
                        vm_call_reason={"reason": reason},
                        vm_callback_no=get_call_back_id(ner),
                    ),
                    settings=settings,
                    vmb_name=vmb_name,
                    ssl_verify=settings.SSL_VERIFY,
                )

                logger.info(f"Started encryption process for file {file_name}")
                protegrity.encrypt_and_upload_to_s3(
                    decoded_file, settings, vmb_name, file_name, s3
                )
                logger.info("Moving email to archive")
                mailbox.move_email_to_archive(msg["id"])
        except RuntimeError as e:
            error_counter += error_counter
            logger.error(
                f"Error while processing email with subject {vmb_name} with exception {str(e)}, continuing with next email"
            )

        finally:
            if decoded_file:
                logger.info(
                    f"Started encryption process for file in finally {file_name}"
                )
                protegrity.encrypt_and_upload_to_s3(
                    decoded_file, settings, vmb_name, file_name, s3
                )

    if not error_counter:
        return {"status": 200, "message": message}
    else:
        return {
            "status": 500,
            "error": f"{error_counter} failed while processing",
        }
