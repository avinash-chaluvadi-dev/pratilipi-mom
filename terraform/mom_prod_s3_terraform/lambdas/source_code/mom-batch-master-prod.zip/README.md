Batch processing scripts
