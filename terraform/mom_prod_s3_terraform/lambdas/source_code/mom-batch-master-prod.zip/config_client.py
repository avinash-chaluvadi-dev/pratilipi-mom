import logging
import os
import time
from pathlib import Path

import requests

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def decrypt(encrypted_txt: str) -> str:
    """
    Decrypts a config string using WorkOS config server endpoint

    :raises Exception if there is an error while decrypting configs

    """
    decrypt_url = os.environ.get(
        "DECRYPT_URL", "https://sit-interlock.anthem.com/pyutilconfig/decrypt"
    )
    cert = os.environ.get("CONFIG_URL_CERT", False)

    headers = {
        "Content-type": "text/plain",
        "authorization": "Basic ZG9ja2VyYWRtaW46ZDBjazNyQGRtMW4=",
    }

    logger.info(f"Decrypt URL used{ decrypt_url}")

    try:
        decrypted_txt = requests.post(
            url=decrypt_url,
            verify=cert,
            headers=headers,
            data=encrypted_txt,
        )
        return decrypted_txt.text
    except Exception as e:
        logger.error(f" Exception while decrypting configs {str(e)}")


def get_soa_configs() -> dict:
    """
    Loads application settings from WorkOS config server

    :raises Exception if config server does not respond with 200 or
                                if there is an error while decrypting configs
    """
    config_url = os.environ.get(
        "CONFIG_URL",
        "https://sit-interlock.anthem.com/pyutilconfig/vmt-soa-gateway-uat,ekssit.json",
    )
    cert = os.environ.get("CONFIG_URL_CERT", False)

    try:
        config_bf_apits = time.time()
        config_resp = requests.get(
            url=config_url,
            verify=cert,
        )
        logger.info(
            f"Total time taken for calling Config server : {time.time()-config_bf_apits} ms with response code : {config_resp.status_code}"
        )

    except Exception as e:
        logger.error(f" Exception while calling config endpoint {str(e)}")
        raise e("Error while loading settings from config server")

    # Decrypt if any ciphers found
    if config_resp.status_code == 200:
        config_resp_json = config_resp.json()
        for (k, v) in config_resp_json.items():
            if str(v).strip().startswith("{" + "cipher" + "}"):
                decrypted_txt = decrypt(v)
                config_resp_json[k] = decrypted_txt

        return config_resp_json

    else:
        logger.error(
            f"Call to config server endpoint failed with status code : {config_resp.status_code} and error{config_resp.text} "
        )
